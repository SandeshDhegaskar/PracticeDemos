# design_patterns
