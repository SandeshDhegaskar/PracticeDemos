package org.strategydesignpattern.finalstrategypattern.fuel;
/*
  @author: chinmay venkat
  Copy rights reserved,Don't use this code for your personal purposes, if we use give credits
 */
public class Diesel implements Fuel{
    @Override
    public String fuel() {
        return "Diesel";
    }
}
