package org.strategydesignpattern.finalstrategypattern.engine;
/*
  @author: chinmay venkat
  Copy rights reserved,Don't use this code for your personal purposes, if we use give credits
 */
public class FourStrokeEngine implements Engine{
    @Override
    public String engine() {
       return "FourStrokeEngine";
    }
}
