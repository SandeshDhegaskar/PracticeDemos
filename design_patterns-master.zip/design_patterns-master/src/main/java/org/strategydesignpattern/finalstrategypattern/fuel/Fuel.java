package org.strategydesignpattern.finalstrategypattern.fuel;
/*
  @author: chinmay venkat
  Copy rights reserved,Don't use this code for your personal purposes, if we use give credits
 */
public interface Fuel {
    public String fuel();
}
