package org.strategydesignpattern.finalstrategypattern.gear;
/*
  @author: chinmay venkat
  Copy rights reserved,Don't use this code for your personal purposes, if we use give credits
 */
public class AutoGear implements Gear{
    @Override
    public String isAutoGear() {
        return "AutoGear";
    }
}
