package org.strategydesignpattern.implementautogear;
/*
  @author: chinmay venkat
  Copy rights reserved,Don't use this code for your personal purposes, if we use give credits
 */
public class Swift extends Car {
    @Override
    public void name() {
       System.out.println("Car name is Swift");
    }

    @Override
    public void engine(){
        System.out.println("it has simple petrol engine");
    }

    @Override
    public void fuel(){
        System.out.println("it has petrol engine");
    }
}
