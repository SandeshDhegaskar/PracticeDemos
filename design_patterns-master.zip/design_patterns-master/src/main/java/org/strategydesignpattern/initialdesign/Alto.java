package org.strategydesignpattern.initialdesign;
/*
  @author: chinmay venkat
  Copy rights reserved,Don't use this code for your personal purposes, if we use give credits
 */
public class Alto extends Car{
    @Override
    public void name() {
        System.out.println("Alto car");
    }
}
