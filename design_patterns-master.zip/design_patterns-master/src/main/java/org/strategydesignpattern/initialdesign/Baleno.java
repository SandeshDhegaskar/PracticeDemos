package org.strategydesignpattern.initialdesign;
/*
  @author: chinmay venkat
  Copy rights reserved,Don't use this code for your personal purposes, if we use give credits
 */
public class Baleno extends Car{

    @Override
    public void name() {
       System.out.println("Car name is Baleno");
    }
}
