package org.observerdesignpattern.finaldesign;

public interface Observer {

    public void update();
}
