package org.observerdesignpattern.initialdesign;

import org.json.JSONObject;

public interface CreateView {
    public Object createView(JSONObject jsonObject);
}
