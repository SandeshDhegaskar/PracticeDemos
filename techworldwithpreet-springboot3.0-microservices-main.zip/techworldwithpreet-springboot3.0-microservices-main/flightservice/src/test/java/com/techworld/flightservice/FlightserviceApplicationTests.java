package com.techworld.flightservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FlightserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
