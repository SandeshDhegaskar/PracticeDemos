package com.nttdemo.fs.flightservice.entity;

public enum Role {
    EMPLOYEE,
    MANAGER,
    SENIOR_MANAGER
}

