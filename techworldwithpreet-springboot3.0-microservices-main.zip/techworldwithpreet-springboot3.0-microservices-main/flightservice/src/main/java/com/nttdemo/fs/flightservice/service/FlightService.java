package com.nttdemo.fs.flightservice.service;

import java.util.List;

import com.nttdemo.fs.flightservice.model.FlightRequest;
import com.nttdemo.fs.flightservice.model.FlightResponse;

public interface FlightService {

    FlightResponse createFlight(FlightRequest flightRequest);

    List<FlightResponse> getAllFlights();

    FlightResponse getFlightByNumber(String flightNumber);

}
