package com.nttdemo.fs.flightservice.entity;

public enum Gender {
    MALE,
    FEMALE,
    OTHER
}
