package com.nttdemo.fs.flightservice.entity;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;



public class Main {
    public static void main(String[] args) throws IOException {
        Predicate<Employee> maleAndAgeGreaterThan25 =
                employee -> Gender.MALE.equals(employee.getGender()) 
                    && employee.getAge() > 25;

        Predicate<Employee> femaleAndManager =
                employee -> Gender.FEMALE.equals(employee.getGender()) 
                    && Role.SENIOR_MANAGER.equals(employee.getRole());


        List<Employee> employees = new ArrayList<>();

        employees.add(new Employee("1", "Tony Stark", 23, Gender.MALE, Role.EMPLOYEE, 25000));
        employees.add(new Employee("2", "Steve Rogers", 28, Gender.MALE, Role.MANAGER, 35000));
        employees.add(new Employee("3", "Natasha Romanoff", 23, Gender.FEMALE, Role.MANAGER, 30000));
        employees.add(new Employee("4", "Wanda Maximoff", 25, Gender.FEMALE, Role.SENIOR_MANAGER, 50000));

        System.out.println("Male and age greater than 25");
        employees.stream()
                .filter(maleAndAgeGreaterThan25)
                .forEach(employee -> System.out.println(employee.toString()));

        System.out.println("\nFemale and Manager");
        employees.stream()
                .filter(femaleAndManager)
                .forEach(employee -> System.out.println(employee.toString()));
    }
}
