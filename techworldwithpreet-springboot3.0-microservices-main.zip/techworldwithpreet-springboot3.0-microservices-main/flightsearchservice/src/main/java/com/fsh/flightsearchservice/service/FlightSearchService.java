package com.fsh.flightsearchservice.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.fsh.flightsearchservice.model.FlightSearchRequest;
import com.fsh.flightsearchservice.model.FlightSearchResponse;

public interface FlightSearchService {

    public List<FlightSearchResponse> searchFlights(FlightSearchRequest flightSearchRequest);
}