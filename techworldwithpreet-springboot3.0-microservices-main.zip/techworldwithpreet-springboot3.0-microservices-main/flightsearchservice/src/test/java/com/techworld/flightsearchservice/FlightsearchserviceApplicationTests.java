package com.techworld.flightsearchservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FlightsearchserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
