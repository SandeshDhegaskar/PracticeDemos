package com.nttdemo.api.apigateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.gateway.route.RouteLocator;
import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
@EnableDiscoveryClient
public class ApiGatewayApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiGatewayApplication.class, args);
	}

	@Bean 
	public RouteLocator customRouteLocator(RouteLocatorBuilder builder) {
		return builder.routes().route("reportId", r ->r.path("/flight-service/**").uri("http://localhost:8081")) 
				
				// static //
 				/*
				 * routing
				 * 
				 * // .route("settlementId", r -> //
				 * r.path("/settlement-service/**").uri("http://localhost:8002")) // static
				 * 
				 * 
				 */
				
				.route("PaymentId",r -> r.path("/payment-service/**").uri("http://localhost:8083"))
				
				.route("bookingId",r->r.path("/Booking-service/**").uri("http://localhost:8084"))
				.build();

	}
	 
}
