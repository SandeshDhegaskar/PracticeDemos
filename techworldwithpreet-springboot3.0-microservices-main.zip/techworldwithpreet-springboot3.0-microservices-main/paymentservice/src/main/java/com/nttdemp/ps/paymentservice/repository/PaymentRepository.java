package com.nttdemp.ps.paymentservice.repository;

import org.springframework.stereotype.Repository;

import com.nttdemp.ps.paymentservice.entity.Payment;

import org.springframework.data.jpa.repository.JpaRepository;

@Repository
public interface PaymentRepository extends JpaRepository<Payment, Long> {

    Payment findByBookingId(Long bookingId);

}
