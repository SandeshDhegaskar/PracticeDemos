package com.nttdemp.ps.paymentservice.service;

import com.nttdemp.ps.paymentservice.model.PaymentRequest;
import com.nttdemp.ps.paymentservice.model.PaymentResponse;

public interface PaymentService {

    long processPayment(PaymentRequest paymentRequest);

    PaymentResponse getPaymentDetailsByBookingId(Long bookingId);

}
