package com.techworld.bookingservice.entity;

public enum BookingStatus {
    CREATED, CONFIRMED, CANCELLED
}
