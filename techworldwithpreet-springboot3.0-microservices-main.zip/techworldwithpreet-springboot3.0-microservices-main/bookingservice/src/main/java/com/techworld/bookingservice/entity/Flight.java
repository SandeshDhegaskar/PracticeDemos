package com.techworld.bookingservice.entity;

public class Flight {

    // Long id;
    // String flightNumber;
    // String origin;
    // String destination;
    // LocalDateTime departureDate,
    // LocalDateTime arrivalTime,
    // int totalSeats;
    // int availableSeats;
    // String airlineCode;
    // String airCraftType;
}
