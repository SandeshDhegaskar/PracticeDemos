# Related Tutorials

- [Spring Boot and Ehcache 3 Example](https://howtodoinjava.com/spring-boot/spring-boot-ehcache-example/)