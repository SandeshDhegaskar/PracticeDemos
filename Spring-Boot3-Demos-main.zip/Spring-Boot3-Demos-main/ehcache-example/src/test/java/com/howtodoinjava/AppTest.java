package com.howtodoinjava;

public class AppTest {

}
