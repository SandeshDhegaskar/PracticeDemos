# Related Tutorials

* [Spring RestClient](https://howtodoinjava.com/spring/spring-restclient/)
* [Fake REST APIs for Unit Testing](https://howtodoinjava.com/angular/mock-rest-server/)
