package com.howtodoinjava;

import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

public class AppTest
{
  @Nested
  @SpringBootTest
    class DemoApplicationTests {

        @Test
        void contextLoads() {
        }

    }
}
