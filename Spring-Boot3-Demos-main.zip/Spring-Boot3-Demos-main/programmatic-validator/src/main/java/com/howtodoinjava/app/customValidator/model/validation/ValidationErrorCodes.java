package com.howtodoinjava.app.customValidator.model.validation;

public class ValidationErrorCodes {

  public static String ERROR_CODE_EMPTY = "error.field.empty";
  public static String ERROR_CODE_SIZE = "error.field.size";
}
