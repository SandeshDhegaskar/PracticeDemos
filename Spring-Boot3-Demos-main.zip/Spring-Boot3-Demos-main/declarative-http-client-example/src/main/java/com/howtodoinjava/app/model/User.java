package com.howtodoinjava.app.model;

public record User(Long id,
                   String name,
                   String username,
                   String email
) {

}
